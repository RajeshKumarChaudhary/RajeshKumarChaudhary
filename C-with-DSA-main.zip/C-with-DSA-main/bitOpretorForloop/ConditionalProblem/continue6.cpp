//  write a program to swith statement using continue function
#include<iostream>
using namespace std;

int main(){
    int month;
    cin>>month;
    switch (month)
    {
    case 1 :
    cout<<" January" ;
        break;
    
    case 2 :
    cout<<" Febuarry" ;
        break;
    
    case 3 :
    cout<<" March" ;
        break;
    
    case 4 :
    cout<<" Aprail" ;
        break;
    
    case 5 :
    cout<<" May" ;
        break;
    
    
    case 6 :
    cout<<" Jun" ;
        break;
    
    case 7 :
    cout<<" July" ;
        break;
    
    case 8 :
    cout<<" August" ;
        break;
    
    case 9 :
    cout<<" September" ;
        continue;
    
    case 10 :
    cout<<" October" ;
        break;
    
    case 11 :
    cout<<" November" ;
        break;
    
    case 12 :
    cout<<" December" ;
        break;
    default:
        cout<<" You have entered default value";
    }
    return 0;
}