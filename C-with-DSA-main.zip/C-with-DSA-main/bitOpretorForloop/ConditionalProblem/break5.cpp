#include<iostream>
using namespace std;

int main(){
    int n; 
    for(int i =1; 1 ;i++){
        cout<<n<<endl;
        exit(1);
        // break;
    }
    return 0;
}

//  we can exits from the loop with the help of break/ exit function