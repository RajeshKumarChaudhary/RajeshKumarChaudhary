#include<iostream>
// #include<math.h>
using namespace std;
int main(){
    int a, b;
    int sum;
    cout<<"Enter the value of a is\n";
   cin>>a;
   cout<<"Enter the value of b is\n";
   cin>>b;
   sum= a+b;
   cout<<"The sum of a b is " <<sum;

}
 

