// ********Break function******
// #include<iostream>
// using namespace std;

// int main(){
//     for(int i=0; i<20; i++){
//         if(i==5){
//             break;
//         }
//         cout<<i<<endl;
//     }
//      return 0;
// }

//*******Continue function*****
#include<iostream>
using namespace std;

int main(){
    for(int i=0; i<20; i++){
         if(i==5){
            continue;  //-------> skip value on i = =5 and continue will be give
         }
      cout<<i<<endl;3
      
    }
    
     return 0;
}