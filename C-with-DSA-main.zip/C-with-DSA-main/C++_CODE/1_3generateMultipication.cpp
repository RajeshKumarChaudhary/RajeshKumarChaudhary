#include<iostream>
#include<math.h>
using namespace std;
int main(){
    int n;
    int multipication;
    cout<<"Enter the value of n \n";
    cin>>n;
   
    for(int i=1; i<10; i++){
        multipication= i*n;
    }
    cout<<"multipication table is "<<multipication;

}
