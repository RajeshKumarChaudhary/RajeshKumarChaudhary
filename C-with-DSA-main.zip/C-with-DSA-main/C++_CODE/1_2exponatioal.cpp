#include<iostream>
#include<math.h>
using namespace std;
int main(){
double value;
double result;
cout<<"Enter the number\n";
cin>>value;
result= exp(value);
cout<<"The exponential of "<< value <<"is "<<result;

    return 0;
}