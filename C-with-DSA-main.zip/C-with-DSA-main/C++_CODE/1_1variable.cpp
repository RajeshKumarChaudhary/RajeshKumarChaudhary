// #include<iostream>
// using namespace std;

// int main(){
//     int sum=5;
//     cout<<"Vijay kumar shah" <<endl<<sum;
    


//     return 0;
// }

#include<iostream>
using namespace std;

int main(){
    
    return 0;
}