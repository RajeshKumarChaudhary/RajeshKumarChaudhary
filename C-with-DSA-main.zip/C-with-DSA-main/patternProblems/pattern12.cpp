//  wap to print pattern
// 1
// 2  1
// 3  2  1
// 4  3  2  1
#include<iostream>
using namespace std;

int main(){
    int n;
    cin>>n;
    int i=1;
    while(i<=n){
        int j=1;
        while(j<=i){
        int value = i;
            // cout<<value-j+ 1<<" ";
            // value= value+1;
            cout<<i-j+1<<" ";
            j= j+1;
        }
   
        cout<<endl;
        i= i+1;
    }
    

    return 0;
}