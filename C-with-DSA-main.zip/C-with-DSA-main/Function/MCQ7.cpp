//  1*********
// #include<iostream>
// using namespace std;
// void update(int a){
//     a = a/2;
// }

// int main(){
//     int n;
//     cin>>n;
//     update(n);
//     cout<<n<<endl;
    
//     return 0;
// }
//  2**********
// #include<iostream>
// using namespace std;
// int update(int a){
//     a-= 5;
//     return a;
// }

// int main(){
//     int n;
//     cin>>n;
//     update(n);
//     cout<<n<<endl;
    
    
// }
//  3**********
#include<iostream>
using namespace std;
int update(int a){
    int ans =a*a;
    return ans;
}

int main(){
    int n;
    cin>>n;
  n=  update(n);
    cout<<n<<endl;
    
    
}